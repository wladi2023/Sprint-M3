let miBoton = document.getElementById("miBoton");

miBoton.addEventListener("click", saludar);
function saludar(){
    alert("Hola, todos los días lunes recibirás nuestras ofertas");
}
miBoton.addEventListener("click", miFuncion);
function miFuncion(){
    alert('¡Muchas gracias!');
}
alert("¡Bienvenidos a Cachureando!");

// miBoton.onclick = saludar;
// miBoton.onclick = despedir;

//evento addEcentListener()
